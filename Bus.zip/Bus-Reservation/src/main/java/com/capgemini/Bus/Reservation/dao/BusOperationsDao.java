package com.capgemini.Bus.Reservation.dao;

import java.util.List;

import com.capgemini.Bus.Reservation.entity.Bus;
import com.capgemini.Bus.Reservation.entity.User;

public interface BusOperationsDao {

	public List<Bus> findallBuses();
	
	public List<User> findallUsers();

	public Bus findById(int theId);
	public void save(Bus theBus);
	public void deletebyId(int theId);


}
