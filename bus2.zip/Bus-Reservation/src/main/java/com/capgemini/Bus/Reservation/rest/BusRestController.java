package com.capgemini.Bus.Reservation.rest;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.Bus.Reservation.dao.BusOperationsDao;
import com.capgemini.Bus.Reservation.entity.Booking;
import com.capgemini.Bus.Reservation.entity.Bus;
import com.capgemini.Bus.Reservation.entity.Passenger;
import com.capgemini.Bus.Reservation.entity.User;

@RestController
@RequestMapping("/api")
public class BusRestController {
	
	private BusOperationsDao busdao;
	
	@Autowired
	public BusRestController(BusOperationsDao theBusOperationsDao) {
		busdao = theBusOperationsDao;
	}

	@GetMapping("/buses")
	public List<Bus> findAllBuses(){
		return busdao.findallBuses();
		
	}
	
	@GetMapping("/users")
	public List<User> findAllUsers(){
		return busdao.findallUsers();
	}
	
	@GetMapping("/buses/{busId}")
	public Bus getBus(@PathVariable int busId) {
	
		Bus theBus = busdao.findById(busId);
		
		if(theBus == null) {
			throw new RuntimeException("Bus id not found"+ theBus);
		}
		return theBus;
		
	}
	
	@GetMapping("/users/booking/{passengerId}")
	public Passenger getPassenger(@PathVariable int passengerId) {
	
		Passenger thePassenger = busdao.passengerfindById(passengerId);
		
		if(thePassenger == null) {
			throw new RuntimeException("user id not found"+ thePassenger);
		}
		return thePassenger;
		
	}
	
	@GetMapping("/users/booking/{bookingId}")
	public Booking getPassengerBookings(@PathVariable int bookingId) {
	
		Booking theBooking = busdao.bookingfindById(bookingId);
		
		if(theBooking == null) {
			throw new RuntimeException("user id not found"+ theBooking);
		}
		return theBooking;
		
	}
	
	@PostMapping("/buses")
	public Bus addBus(@RequestBody Bus theBus) {
		theBus.setBusId(0);
		busdao.save(theBus);
		return theBus;	
	}
	
	@PostMapping("/users")
	public Passenger addPassenger(@RequestBody Passenger thePassenger) {
		
		busdao.savePassenger(thePassenger);
		return thePassenger;	
	}
	
	@PostMapping("/booking/users")
	public Booking addBooking(@RequestBody Booking theBooking) {
		
		busdao.saveBookings(theBooking);
		return theBooking;	
	}
	
	
	@PutMapping("/buses")
	public Bus updateBus(@RequestBody Bus theBus)
	{
		busdao.save(theBus);
		
		return theBus;
	}
	
	@DeleteMapping("/buses/{busId}")
	public String deleteBus(@PathVariable int busId) {
		Bus tempBus = busdao.findById(busId);
		if(tempBus == null) {
			throw new RuntimeException("bus not found");
		}
		
		busdao.deletebyId(busId);
		
		return "Delete bus "+busId;
	}
	
	@DeleteMapping("/users/booking/{bookingId}")
	public String deleteBooking(@PathVariable int bookingId) {
		Booking tempBooking = busdao.bookingfindById(bookingId);
		if(tempBooking == null) {
			throw new RuntimeException("booking not found");
		}
		
		busdao.deletebookingbyId(bookingId);
		
		return "Delete bus "+bookingId;
	}
	
	
	
}
