package com.capgemini.Bus.Reservation.dao;

import java.util.List;

import javax.persistence.EntityManager;

import org.hibernate.Session;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.capgemini.Bus.Reservation.entity.Booking;
import com.capgemini.Bus.Reservation.entity.Bus;
import com.capgemini.Bus.Reservation.entity.Passenger;
import com.capgemini.Bus.Reservation.entity.User;

@Repository
public class BusOperationDaoImpl implements BusOperationsDao{
	
	private EntityManager entityManager;
	
	@Autowired
	public BusOperationDaoImpl(EntityManager theEntityManager) {
		entityManager = theEntityManager;
	}

	@Override
	@Transactional
	public List<Bus> findallBuses() {
		// TODO Auto-generated method stub
		Session currentSession = entityManager.unwrap(Session.class);
		Query<Bus> theQuery = currentSession.createQuery("from Bus",Bus.class);
		List<Bus> buses = theQuery.getResultList();
		return buses;
	}
	
	@Override
	@Transactional
	public List<User> findallUsers() {
		// TODO Auto-generated method stub
		Session currentSession = entityManager.unwrap(Session.class);
		Query<User> theQuery = currentSession.createQuery("from User",User.class);
		List<User> users = theQuery.getResultList();
		return users;
	}

	@Override
	@Transactional
	public Bus findById(int theId) {
		// TODO Auto-generated method stub
		Session currentSession = entityManager.unwrap(Session.class);
		Bus theBus = currentSession.get(Bus.class, theId);
		return theBus;
	}
	
	

	@Override
	@Transactional

	public void save(Bus theBus) {
		// TODO Auto-generated method stub
		Session currentSession = entityManager.unwrap(Session.class);
		currentSession.saveOrUpdate(theBus);
		
	}

	@Override
	@Transactional

	public void deletebyId(int theId) {
		// TODO Auto-generated method stub
		Session currentSession = entityManager.unwrap(Session.class);
		Query thequery = currentSession.createQuery(
				"delete from Bus where id =: busId");
		thequery.setParameter("busId", theId);
		thequery.executeUpdate();
		
		
	}

	@Override
	@Transactional
	public Passenger passengerfindById(int theId) {
		Session currentSession = entityManager.unwrap(Session.class);
		Passenger thePassenger = currentSession.get(Passenger.class, theId);
		return thePassenger;
	}

	@Override
	@Transactional
	public void savePassenger(Passenger thePassenger) {
		// TODO Auto-generated method stub
		Session currentSession = entityManager.unwrap(Session.class);
		currentSession.saveOrUpdate(thePassenger);
	}

	@Override
	@Transactional
	public void saveBookings(Booking theBooking) {
		// TODO Auto-generated method stub
		Session currentSession = entityManager.unwrap(Session.class);
		currentSession.saveOrUpdate(theBooking);
	}

	@Override
	@Transactional
	public Booking bookingfindById(int theId) {
		Session currentSession = entityManager.unwrap(Session.class);
		Booking theBooking = currentSession.get(Booking.class, theId);
		return theBooking;
	}

	@Override
	@Transactional
	public void deletebookingbyId(int theId) {
		// TODO Auto-generated method stub
		Session currentSession = entityManager.unwrap(Session.class);
		Query thequery = currentSession.createQuery(
				"delete from Booking where id =: bookingId");
		thequery.setParameter("bookingId", theId);
		thequery.executeUpdate();
	}

}
